var searchData=
[
  ['triangle_2ecpp',['triangle.cpp',['../triangle_8cpp.html',1,'']]],
  ['triangle_2ed',['triangle.d',['../triangle_8d.html',1,'']]]
];
